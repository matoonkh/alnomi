<?php
if (isset($_POST["submit"])) {
    $targetDirectory = "uploads/"; // Specify the directory where you want to store the uploaded files
    $targetFile = $targetDirectory . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    
    // Check if the file already exists
    if (file_exists($targetFile)) {
        echo "File already exists.";
        $uploadOk = 0;
    }
    
    // Check file size (optional)
    if ($_FILES["fileToUpload"]["size"] > 1000000) {
        echo "File is too large.";
        $uploadOk = 0;
    }
    
    // Check the file's file type (MIME type, you can customize this)
    $allowedFileTypes = array("jpg", "jpeg", "png", "gif","pdf");
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    if (!in_array($fileType, $allowedFileTypes)) {
        echo "Only JPG, JPEG, PNG, and GIF files are allowed.";
        $uploadOk = 0;
    }
    
    if ($uploadOk == 0) {
        echo "File upload failed.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
            echo "File has been uploaded.";
        } else {
            echo "Error uploading the file.";
        }
    }
}
?>
