

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Upload a File</h1>

        <form action="<?php echo e(route('upload')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="file">Choose a file:</label>
                <input type="file" name="file" id="file" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
<br/><br/>
        <?php if(session('success')): ?>
    <div class="alert alert-success">
    <a href="<?php echo e(url('/')); ?>/<?php echo e(session('success')); ?>"><?php echo e(url('/')); ?>/<?php echo e(session('success')); ?></a>

    
    </div>
<?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book_alnoman\resources\views/upload.blade.php ENDPATH**/ ?>