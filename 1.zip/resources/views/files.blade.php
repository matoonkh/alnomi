@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>All Files</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Download Link</th>
                </tr>
            </thead>
            <tbody>
                @foreach($files as $file)
                    <tr>
                        <td>{{ $file->id }}</td>
                        <td>{{ $file->name }}</td>
                        <td>
                            <!-- <a href="{{ asset('storage/' . $file->path) }}" target="_blank">Download</a> -->
                            <a href="{{ asset('' . $file->path) }}" target="_blank"> View</a>

                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
