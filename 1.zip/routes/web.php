<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FileController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('clear-cache', function() { 
    Artisan::call('cache:clear'); 
    Artisan::call('view:clear'); 
    Artisan::call('route:clear'); 
    Artisan::call('config:clear'); 
    return "Cache is cleared..."; 
    
});

Route::get('/', function () { 
    return view('upload'); 
    // return view('welcome'); 
})->name('home');


Route::get('/index',  [FileController::class,'index'])->name('index');
Route::get('/files', [FileController::class,'showAllFiles'])->name('files.index');

Route::get('/file/download/{id}', [FileController::class,'download']);

Route::post('/file/upload', [FileController::class,'upload2'])->name('file.upload');

Route::post('/upload', [FileController::class,'upload2'])->name('upload');
Route::get('/files/list', [FileController::class,'listFiles'])->name('files.list');


/*
this link is working on the local server url#
http://localhost:8080/uploads/__ia_thumb.jpg

this link is working on the real live linux server url#
https://jafrani.blogvali.com/public/uploads/__ia_thumb%20(1).jpg
*/