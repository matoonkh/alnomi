@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>List of Files</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>File Size</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($files as $file)
                    <tr>
                    <td> <a href="{{ url('/public/uploads') }}/{{ $file['name'] }}">{{ url('/public/uploads') }}/{{ $file['name'] }}</a></td>

                        <td>{{ $file['name'] }}</td>
                        <td>{{ $file['size'] }} bytes</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
