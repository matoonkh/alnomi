

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>List of Files</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>File Size</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td> <a href="<?php echo e(url('/uploads')); ?>/<?php echo e($file['name']); ?>"><?php echo e(url('/uploads')); ?>/<?php echo e($file['name']); ?></a></td>

                        <td><?php echo e($file['name']); ?></td>
                        <td><?php echo e($file['size']); ?> bytes</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book_alnoman\resources\views/file_list.blade.php ENDPATH**/ ?>