

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>All Files</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Download Link</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($file->id); ?></td>
                        <td><?php echo e($file->name); ?></td>
                        <td>
                            <!-- <a href="<?php echo e(asset('storage/' . $file->path)); ?>" target="_blank">Download</a> -->
                            <a href="<?php echo e(asset('' . $file->path)); ?>" target="_blank"> View</a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book_alnoman\resources\views/files.blade.php ENDPATH**/ ?>