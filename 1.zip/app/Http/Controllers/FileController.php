<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Filex;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
class FileController extends Controller{

        public function listFiles(){
            $directory = 'public/uploads'; // Adjust the directory path as needed
            $files = collect(File::files($directory))->map(function ($file) {
                return [
                    'name' => $file->getFilename(),
                    'path' => $file->getRealPath(),
                    'size' => $file->getSize(),
                ];
            });
    
            return view('file_list', ['files' => $files]);
        }
    
    

    //=========================================
    public function showAllFiles(){
    $files = Filex::all(); // Fetch all file records from the database

    return view('files', ['files' => $files]);
}

// Get all admin users
public function index(){
        $adminUsers = Filex::all();
        return response()->json($adminUsers, 200);
    }

    //
    public function upload(Request $request){
    $file = $request->file('file');
    $path = $file->store('uploads');
    // Save file information to the database
    // Redirect or return a response
}

public function upload2(Request $request){
        // Validate the uploaded file
        $request->validate([
            'file' => 'required|file|mimes:pdf,jpg,png,doc,docx|max:2048', // Adjust validation rules as needed
        ]);

        // Retrieve the uploaded file
        $uploadedFile = $request->file('file');


        // Generate a unique file name and store it in the 'uploads' directory
        // $fileName = time() . '_' . $uploadedFile->getClientOriginalName();
        $fileName = $uploadedFile->getClientOriginalName();

        // $path = $uploadedFile->storeAs('uploads', $fileName);
        $path = $uploadedFile->storeAs('uploads', $fileName, 'public');
        // $path = $uploadedFile->store('uploads', 'public');

        // Create a record of the uploaded file in the database
        // $file = new Filex();
        // $file->name = $uploadedFile->getClientOriginalName();
        // $file->path = $path;
        // $file->save();

        // Redirect back with a success message
        return redirect()->back()->with('success', $path);
    }
}
