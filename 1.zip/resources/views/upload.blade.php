@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Upload a File</h1>

        <form action="{{ route('upload') }}" method="post" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label for="file">Choose a file:</label>
                <input type="file" name="file" id="file" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
<br/><br/>
        @if(session('success'))
    <div class="alert alert-success">
    <a href="{{ url('/') }}/{{ session('success') }}">{{ url('/') }}/{{ session('success') }}</a>

    
    </div>
@endif

    </div>
@endsection
